See chat-agent.html (상담사 채팅 콘솔) and chat-customer.html(고객 채팅 콘솔)


http://192.168.8.81:28070/frontend/chat-agent.html

http://192.168.8.81:28070/frontend/chat-customer.html