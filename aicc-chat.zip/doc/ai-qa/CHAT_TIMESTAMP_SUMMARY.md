# chat-customer.html 개선 요약

## ✅ 구현 완료

chat-customer.html에 다음 두 가지 기능이 추가되었습니다:
1. **방 제목 영역에 Room ID 표시**
2. **메시지 발행 시 타임스탬프(년월일시분초) 표시**

---

## 🎨 화면 변경

### Before
```
┌─────────────────────────────────────┐
│ 배송문의              [버튼들]       │
├─────────────────────────────────────┤
│ 홍길철                               │
│ 안녕하세요?                          │
└─────────────────────────────────────┘
```

### After
```
┌─────────────────────────────────────┐
│ 배송문의              [버튼들]       │
│ 방 ID: room-a1b2c3d4                │ ← ✅ Room ID 추가
├─────────────────────────────────────┤
│ 홍길철                               │
│ 안녕하세요?                          │
│ 2026-01-26 14:30:45                 │ ← ✅ 타임스탬프 추가
└─────────────────────────────────────┘
```

---

## 🔧 주요 변경 사항

### 1. Room ID 표시

#### HTML 구조
```html
<div class="d-flex justify-content-between align-items-center mb-2">
    <div>
        <span id="room-title" class="fw-bold"></span>
        <div id="room-id" class="room-info"></div> <!-- ✅ 추가 -->
    </div>
    <!-- 버튼들 -->
</div>
```

#### JavaScript
```javascript
// connect() 함수에서 Room ID 표시
document.getElementById("room-title").innerText = 
    document.getElementById("roomName").value || "상담 중";
document.getElementById("room-id").innerText = 
    `방 ID: ${currentRoomId}`; // ✅ Room ID 표시
```

#### CSS
```css
.room-info { 
    font-size: 0.85em; 
    color: #666; 
}
```

---

### 2. 타임스탬프 표시

#### 타임스탬프 생성 함수
```javascript
/**
 * 현재 시간을 "YYYY-MM-DD HH:mm:ss" 형식으로 반환
 */
function getCurrentTimestamp() {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');
    
    return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
}
```

**예시 출력:**
- `2026-01-26 14:30:45`
- `2026-12-31 23:59:59`

#### 메시지 표시 로직
```javascript
function showMessage(message) {
    const timestamp = getCurrentTimestamp(); // ✅ 타임스탬프 생성

    if (message.type === 'JOIN' || message.type === 'LEAVE') {
        // 시스템 메시지
        div.innerText = `[${timestamp}] ${message.message}`;
    } else {
        // 일반 채팅 메시지
        div.innerHTML = `
            <div class="fw-bold">${message.sender}</div>
            <div class="content">${message.message}</div>
            <div class="timestamp">${timestamp}</div> <!-- ✅ 추가 -->
        `;
    }
}
```

#### CSS
```css
/* 타임스탬프 스타일 */
.message .timestamp { 
    font-size: 10px; 
    color: #999; 
    margin-top: 2px; 
}

/* 내 메시지 타임스탬프 (밝은 색) */
.message.my .timestamp { 
    color: #ccc; 
}
```

---

## 📊 타임스탬프 형식

### 형식: `YYYY-MM-DD HH:mm:ss`

| 요소 | 설명 | 예시 |
|------|------|------|
| YYYY | 4자리 연도 | 2026 |
| MM | 2자리 월 | 01 |
| DD | 2자리 일 | 26 |
| HH | 2자리 시 (24시간) | 14 |
| mm | 2자리 분 | 30 |
| ss | 2자리 초 | 45 |

---

## 🎯 화면 예시

```
┌──────────────────────────────────────────────────────┐
│  고객 상담 채팅                                        │
├──────────────────────────────────────────────────────┤
│  배송문의                        [상담원 연결] [종료]  │
│  방 ID: room-a1b2c3d4                                 │
├──────────────────────────────────────────────────────┤
│  [2026-01-26 14:28:10] 홍길철님이 입장하셨습니다.    │
│                                                        │
│  ┌──────────────────────────┐                         │
│  │ 봇                        │                         │
│  │ 안녕하세요! 무엇을       │                         │
│  │ 도와드릴까요?            │                         │
│  │ 2026-01-26 14:28:11      │                         │
│  └──────────────────────────┘                         │
│                                                        │
│                   ┌──────────────────────────┐        │
│                   │ 홍길철                    │        │
│                   │ 배송 문의드립니다.        │        │
│                   │ 2026-01-26 14:28:45      │        │
│                   └──────────────────────────┘        │
│                                                        │
│  ┌──────────────────────────┐                         │
│  │ 봇                        │                         │
│  │ 주문번호를 알려주시겠어요?│                         │
│  │ 2026-01-26 14:28:46      │                         │
│  └──────────────────────────┘                         │
├──────────────────────────────────────────────────────┤
│ [메시지 입력...]                           [전송]     │
└──────────────────────────────────────────────────────┘
```

---

## 🧪 테스트 방법

### 1. Room ID 확인
```
1. 로그인 (cust01 / 1234)
2. 상담 시작
3. 채팅 화면 상단에서 확인
   ✅ "방 ID: room-xxxxxxxx" 표시
4. 콘솔 확인
   console.log(currentRoomId);
```

### 2. 타임스탬프 확인
```
1. 로그인 후 상담 시작
2. 메시지 전송
   ✅ 메시지 하단에 타임스탬프 표시
   예: "2026-01-26 14:30:45"
3. 시스템 메시지 확인
   ✅ "[2026-01-26 14:28:10] 홍길철님이 입장하셨습니다."
```

### 3. 시간 정확도 테스트
```
1. 메시지 전송 시간과 타임스탬프 비교
2. 1분 간격으로 여러 메시지 전송
3. 타임스탬프가 정확히 증가하는지 확인
```

---

## 🔍 브라우저 개발자 도구 확인

### 콘솔 (F12)
```javascript
// Room ID 확인
console.log('Room ID:', currentRoomId);
// 출력: "Room ID: room-a1b2c3d4"

// 타임스탬프 생성 테스트
console.log(getCurrentTimestamp());
// 출력: "2026-01-26 14:30:45"

// 모든 타임스탬프 확인
document.querySelectorAll('.timestamp').forEach(ts => {
    console.log(ts.innerText);
});
```

### Elements 탭
```
1. F12 → Elements
2. #room-id 검색
   ✅ "방 ID: room-a1b2c3d4"
3. .timestamp 검색
   ✅ 각 메시지에 타임스탬프 표시
```

---

## 💡 커스터마이징 옵션

### 1. 타임스탬프 형식 변경

**시:분만 표시**
```javascript
function getCurrentTimestamp() {
    const now = new Date();
    return `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
}
// 출력: "14:30"
```

**날짜 + 시:분**
```javascript
function getCurrentTimestamp() {
    const now = new Date();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    return `${month}-${day} ${hours}:${minutes}`;
}
// 출력: "01-26 14:30"
```

### 2. Room ID 복사 기능 추가

```html
<div id="room-id" class="room-info" 
     onclick="copyRoomId()" 
     style="cursor: pointer;" 
     title="클릭하여 복사">
    방 ID: room-abc123
</div>
```

```javascript
function copyRoomId() {
    navigator.clipboard.writeText(currentRoomId)
        .then(() => alert('방 ID가 복사되었습니다: ' + currentRoomId))
        .catch(err => console.error('복사 실패:', err));
}
```

### 3. 타임스탬프 색상 변경

```css
/* 더 진한 회색 */
.message .timestamp { 
    color: #666; /* 기본: #999 */
}

/* 내 메시지 타임스탬프 더 밝게 */
.message.my .timestamp { 
    color: #eee; /* 기본: #ccc */
}
```

---

## 📚 생성된 문서

- **CHAT_TIMESTAMP_ROOMID_GUIDE.md** - 상세 가이드
  - 전체 코드 설명
  - 화면 예시
  - 고급 기능 제안
  - 디버깅 방법
  - 커스터마이징 옵션

---

## ✅ 체크리스트

- [x] Room ID HTML 구조 추가
- [x] Room ID CSS 스타일 추가
- [x] Room ID 표시 로직 구현 (connect 함수)
- [x] 타임스탬프 생성 함수 구현 (getCurrentTimestamp)
- [x] 타임스탬프 CSS 스타일 추가
- [x] 일반 메시지에 타임스탬프 표시
- [x] 시스템 메시지에 타임스탬프 표시
- [x] 내 메시지/상대방 메시지 스타일 구분
- [x] 상세 가이드 문서 작성
- [x] 요약 문서 작성

---

## 🎉 완료

chat-customer.html에 Room ID 표시 및 타임스탬프 기능이 성공적으로 추가되었습니다!

**구현된 기능:**
- ✅ 방 제목 아래에 Room ID 표시 (`방 ID: room-xxxxxxxx`)
- ✅ 모든 메시지에 년월일시분초 타임스탬프 표시 (`YYYY-MM-DD HH:mm:ss`)
- ✅ 시스템 메시지에도 타임스탬프 포함 (`[타임스탬프] 메시지`)
- ✅ 깔끔한 스타일링 (작고 눈에 거슬리지 않음)
- ✅ 내 메시지와 상대방 메시지 타임스탬프 색상 구분

**테스트 완료:**
- ✅ Room ID 정확하게 표시됨
- ✅ 타임스탬프 형식 정확함
- ✅ 실시간으로 정확한 시간 표시
- ✅ 스타일 적용 완료
