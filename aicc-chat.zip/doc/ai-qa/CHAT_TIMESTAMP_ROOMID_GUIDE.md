# chat-customer.html 개선 - Room ID 및 타임스탬프 표시 가이드

## 📋 개요

chat-customer.html에 다음 두 가지 기능을 추가했습니다:
1. **방 제목 영역에 Room ID 표시**
2. **메시지 발행 시 타임스탬프(년월일시분초) 표시**

---

## 🎨 UI 변경 사항

### 1. 방 제목 영역에 Room ID 추가

#### Before
```
┌─────────────────────────────────────────┐
│ 배송문의                     [버튼들]    │
└─────────────────────────────────────────┘
```

#### After
```
┌─────────────────────────────────────────┐
│ 배송문의                     [버튼들]    │
│ 방 ID: room-abc12345                    │
└─────────────────────────────────────────┘
```

#### HTML 구조
```html
<div class="d-flex justify-content-between align-items-center mb-2">
    <div>
        <span id="room-title" class="fw-bold"></span>
        <div id="room-id" class="room-info"></div> <!-- 추가됨 -->
    </div>
    <div>
        <!-- 버튼들 -->
    </div>
</div>
```

### 2. 메시지에 타임스탬프 추가

#### Before
```
┌─────────────────────────────┐
│ 홍길철                       │
│ 안녕하세요?                  │
└─────────────────────────────┘
```

#### After
```
┌─────────────────────────────┐
│ 홍길철                       │
│ 안녕하세요?                  │
│ 2026-01-26 14:30:45         │
└─────────────────────────────┘
```

---

## 🔧 코드 변경 사항

### 1. CSS 스타일 추가

```css
/* 메시지 타임스탬프 스타일 */
.message .timestamp { 
    font-size: 10px; 
    color: #999; 
    margin-top: 2px; 
}

/* 내 메시지 타임스탬프 (밝은 색) */
.message.my .timestamp { 
    color: #ccc; 
}

/* Room ID 표시 스타일 */
.room-info { 
    font-size: 0.85em; 
    color: #666; 
}
```

### 2. Room ID 표시 로직

**connect() 함수 수정:**
```javascript
function connect() {
    stompClient.connect({}, function (frame) {
        console.log('WebSocket 연결 성공: ' + frame);
        
        // UI 전환
        document.getElementById("connect-form").style.display = "none";
        document.getElementById("chat-page").style.display = "block";
        
        // 방 제목과 roomId 표시 (추가됨)
        document.getElementById("room-title").innerText = 
            document.getElementById("roomName").value || "상담 중";
        document.getElementById("room-id").innerText = 
            `방 ID: ${currentRoomId}`; // ✅ Room ID 표시
        
        // ... 나머지 코드
    });
}
```

### 3. 타임스탬프 생성 함수

```javascript
/**
 * 현재 시간을 "YYYY-MM-DD HH:mm:ss" 형식으로 반환
 */
function getCurrentTimestamp() {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');
    
    return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
}
```

**예시 출력:**
- `2026-01-26 14:30:45`
- `2026-12-31 23:59:59`

### 4. 메시지 표시 로직 수정

**showMessage() 함수 수정:**
```javascript
function showMessage(message) {
    const chatBox = document.getElementById("chat-box");
    const div = document.createElement("div");
    const timestamp = getCurrentTimestamp(); // ✅ 타임스탬프 생성

    if (message.type === 'JOIN' || message.type === 'LEAVE') {
        // 시스템 메시지 (JOIN, LEAVE)
        div.className = "system";
        div.innerText = `[${timestamp}] ${message.message}`; // ✅ 타임스탬프 포함
    } else {
        // 일반 채팅 메시지
        const isMe = message.senderRole === 'CUSTOMER';
        div.className = isMe ? "message my" : "message other";
        div.innerHTML = `
            <div class="fw-bold" style="font-size:12px; margin-bottom:2px;">
                ${message.sender}
            </div>
            <div class="content">${message.message}</div>
            <div class="timestamp">${timestamp}</div> <!-- ✅ 타임스탬프 추가 -->
        `;
    }
    
    chatBox.appendChild(div);
    chatBox.scrollTop = chatBox.scrollHeight;
}
```

---

## 🎯 화면 예시

### 전체 채팅 화면
```
┌──────────────────────────────────────────────────────────┐
│  고객 상담 채팅                                            │
├──────────────────────────────────────────────────────────┤
│  배송문의                              [상담원 연결] [종료] │
│  방 ID: room-a1b2c3d4                                     │
├──────────────────────────────────────────────────────────┤
│                                                            │
│  [2026-01-26 14:28:10] 홍길철님이 입장하셨습니다.         │
│                                                            │
│  ┌────────────────────────────────┐                       │
│  │ 봇                              │                       │
│  │ 안녕하세요! 무엇을 도와드릴까요?│                       │
│  │ 2026-01-26 14:28:11            │                       │
│  └────────────────────────────────┘                       │
│                                                            │
│                       ┌────────────────────────────────┐  │
│                       │ 홍길철                          │  │
│                       │ 배송 문의드립니다.              │  │
│                       │ 2026-01-26 14:28:45            │  │
│                       └────────────────────────────────┘  │
│                                                            │
│  ┌────────────────────────────────┐                       │
│  │ 봇                              │                       │
│  │ 주문번호를 알려주시겠어요?      │                       │
│  │ 2026-01-26 14:28:46            │                       │
│  └────────────────────────────────┘                       │
│                                                            │
├──────────────────────────────────────────────────────────┤
│ [메시지 입력...]                               [전송]     │
└──────────────────────────────────────────────────────────┘
```

---

## 📊 타임스탬프 형식

### 형식: `YYYY-MM-DD HH:mm:ss`

| 요소 | 설명 | 예시 |
|------|------|------|
| YYYY | 4자리 연도 | 2026 |
| MM | 2자리 월 (01-12) | 01, 12 |
| DD | 2자리 일 (01-31) | 26, 31 |
| HH | 2자리 시 (00-23) | 14, 23 |
| mm | 2자리 분 (00-59) | 30, 59 |
| ss | 2자리 초 (00-59) | 45, 59 |

### 예시
- `2026-01-26 14:30:45`
- `2026-12-31 23:59:59`
- `2026-03-15 09:05:03`

---

## 🧪 테스트 시나리오

### 시나리오 1: Room ID 표시 확인
```
1. 로그인 (cust01 / 1234)
2. 상담 시작
3. 채팅 화면에서 Room ID 확인
   - 예: "방 ID: room-a1b2c3d4"
4. 브라우저 콘솔에서 확인
   console.log(currentRoomId); // "room-a1b2c3d4"
```

### 시나리오 2: 메시지 타임스탬프 확인
```
1. 로그인 후 상담 시작
2. "안녕하세요" 메시지 전송
3. 메시지 하단에 타임스탬프 확인
   - 예: "2026-01-26 14:30:45"
4. 1분 후 "배송 문의드립니다" 전송
5. 타임스탬프가 1분 차이로 표시되는지 확인
   - 예: "2026-01-26 14:31:46"
```

### 시나리오 3: 시스템 메시지 타임스탬프
```
1. 로그인 후 상담 시작
2. 입장 메시지 확인
   - "[2026-01-26 14:28:10] 홍길철님이 입장하셨습니다."
3. 상담원 연결 요청
4. 시스템 메시지 확인
   - "[2026-01-26 14:28:30] 상담원과 연결되었습니다."
```

### 시나리오 4: 자정 경계 테스트
```
1. 23:59:50에 메시지 전송
   - "2026-01-26 23:59:50"
2. 00:00:10에 메시지 전송
   - "2026-01-27 00:00:10" (날짜 변경 확인)
```

---

## 🎨 스타일 커스터마이징

### 1. 타임스탬프 색상 변경

```css
/* 일반 메시지 타임스탬프 */
.message .timestamp { 
    font-size: 10px; 
    color: #888; /* 기본: #999 → 변경: #888 (더 진한 회색) */
    margin-top: 2px; 
}

/* 내 메시지 타임스탬프 */
.message.my .timestamp { 
    color: #ddd; /* 기본: #ccc → 변경: #ddd (더 밝은 색) */
}
```

### 2. 타임스탬프 크기 변경

```css
.message .timestamp { 
    font-size: 11px; /* 기본: 10px → 변경: 11px */
    color: #999; 
    margin-top: 2px; 
}
```

### 3. Room ID 스타일 변경

```css
.room-info { 
    font-size: 0.8em;     /* 더 작게 */
    color: #999;          /* 더 밝은 회색 */
    font-style: italic;   /* 이탤릭체 */
}
```

### 4. 타임스탬프 위치 변경

```css
/* 타임스탬프를 메시지 오른쪽에 표시 */
.message .content-wrapper {
    display: flex;
    align-items: baseline;
    gap: 5px;
}
```

---

## 💡 고급 기능 제안

### 1. 상대 시간 표시 (옵션)

```javascript
/**
 * 상대 시간 표시 (예: "방금 전", "5분 전")
 */
function getRelativeTime(timestamp) {
    const now = new Date();
    const messageTime = new Date(timestamp);
    const diffMs = now - messageTime;
    const diffSec = Math.floor(diffMs / 1000);
    const diffMin = Math.floor(diffSec / 60);
    const diffHour = Math.floor(diffMin / 60);
    
    if (diffSec < 60) return '방금 전';
    if (diffMin < 60) return `${diffMin}분 전`;
    if (diffHour < 24) return `${diffHour}시간 전`;
    return getCurrentTimestamp(); // 1일 이상이면 전체 날짜 표시
}
```

### 2. 타임스탬프 포맷 옵션

```javascript
/**
 * 타임스탬프 포맷 변경 옵션
 */
function getCurrentTimestamp(format = 'full') {
    const now = new Date();
    
    switch(format) {
        case 'time-only':
            // 시:분만 표시 (예: "14:30")
            return `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
        
        case 'short':
            // 날짜 + 시:분 (예: "01-26 14:30")
            return `${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
        
        case 'full':
        default:
            // 전체 (예: "2026-01-26 14:30:45")
            return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`;
    }
}

// 사용 예시
const timestamp = getCurrentTimestamp('time-only'); // "14:30"
```

### 3. Room ID 복사 기능

```html
<div id="room-id" class="room-info" onclick="copyRoomId()" style="cursor: pointer;" title="클릭하여 복사">
    방 ID: room-abc123
</div>
```

```javascript
function copyRoomId() {
    navigator.clipboard.writeText(currentRoomId)
        .then(() => {
            alert('방 ID가 복사되었습니다: ' + currentRoomId);
        })
        .catch(err => {
            console.error('복사 실패:', err);
        });
}
```

---

## 🔍 디버깅

### 브라우저 개발자 도구 (F12)

#### 콘솔에서 확인
```javascript
// Room ID 확인
console.log('Current Room ID:', currentRoomId);

// 타임스탬프 생성 테스트
console.log('Current Timestamp:', getCurrentTimestamp());

// 모든 메시지 타임스탬프 확인
document.querySelectorAll('.timestamp').forEach(ts => {
    console.log('Timestamp:', ts.innerText);
});
```

#### Elements 탭에서 확인
```
1. F12 → Elements 탭
2. #room-id 요소 검색
3. innerText 확인: "방 ID: room-abc123"
4. .timestamp 요소들 검색
5. 각 메시지의 타임스탬프 확인
```

---

## 📝 요약

### 추가된 기능

1. **Room ID 표시**
   - 위치: 방 제목 아래
   - 형식: `방 ID: room-{uuid}`
   - 스타일: 작은 회색 텍스트

2. **메시지 타임스탬프**
   - 형식: `YYYY-MM-DD HH:mm:ss`
   - 위치: 메시지 내용 아래
   - 스타일: 
     - 일반 메시지: 회색 (#999)
     - 내 메시지: 밝은 회색 (#ccc)
     - 시스템 메시지: `[타임스탬프] 메시지` 형식

### 수정된 파일
- ✅ `chat-customer.html`
  - CSS 스타일 추가
  - HTML 구조 수정 (room-id div 추가)
  - `connect()` 함수 수정 (Room ID 표시)
  - `getCurrentTimestamp()` 함수 추가
  - `showMessage()` 함수 수정 (타임스탬프 표시)

### 테스트 완료
- [x] Room ID가 화면에 표시됨
- [x] 메시지마다 타임스탬프가 표시됨
- [x] 시스템 메시지에도 타임스탬프가 표시됨
- [x] 타임스탬프 형식이 정확함 (YYYY-MM-DD HH:mm:ss)
- [x] 스타일이 적절하게 적용됨

---

## 🎉 완료

chat-customer.html에 Room ID 표시 및 메시지 타임스탬프 기능이 성공적으로 추가되었습니다!

**주요 개선 사항:**
- ✅ 방 제목 영역에 Room ID 표시
- ✅ 모든 메시지에 년월일시분초 타임스탬프 표시
- ✅ 시스템 메시지에도 타임스탬프 표시
- ✅ 깔끔한 스타일링 (작고 눈에 거슬리지 않음)
- ✅ 내 메시지와 상대방 메시지 타임스탬프 색상 구분
